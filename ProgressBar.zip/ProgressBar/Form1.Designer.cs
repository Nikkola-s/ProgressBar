﻿namespace ProgressBar
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            progressBar1 = new System.Windows.Forms.ProgressBar();
            textBox1 = new TextBox();
            btnStartReading = new Button();
            SuspendLayout();
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(23, 22);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(593, 29);
            progressBar1.TabIndex = 0;
            progressBar1.Click += Form1_Load;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(23, 68);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.ScrollBars = ScrollBars.Vertical;
            textBox1.Size = new Size(749, 338);
            textBox1.TabIndex = 1;
            // 
            // btnStartReading
            // 
            btnStartReading.Location = new Point(631, 25);
            btnStartReading.Name = "btnStartReading";
            btnStartReading.Size = new Size(118, 29);
            btnStartReading.TabIndex = 2;
            btnStartReading.Text = "Старт";
            btnStartReading.UseVisualStyleBackColor = true;
            btnStartReading.Click += btnStartReading_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnStartReading);
            Controls.Add(textBox1);
            Controls.Add(progressBar1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ProgressBar progressBar1;
        private TextBox textBox1;
        private Button btnStartReading;
    }
}